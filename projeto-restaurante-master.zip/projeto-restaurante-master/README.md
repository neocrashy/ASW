# projeto-restaurante
Sistema de Restaurante desenvolvido durante a disciplina de Java para Web, usando Spring MVC, JSP, JPA, Hibernate.
