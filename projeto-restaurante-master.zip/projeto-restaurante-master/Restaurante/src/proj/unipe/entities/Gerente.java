package proj.unipe.entities;

import javax.persistence.Entity;

@Entity
public class Gerente extends Usuario {

}
