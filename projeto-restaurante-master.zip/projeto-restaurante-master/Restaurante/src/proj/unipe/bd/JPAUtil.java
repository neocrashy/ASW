package proj.unipe.bd;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
//classe respons�vel por fornecer a instancia de entitymanager aos services que ir�o utilizar esse entitymanager
public class JPAUtil {
	/*
	static EntityManagerFactory fac = Persistence.createEntityManagerFactory("Restaurante");

	public static EntityManager getEntityManager(){
		return fac.createEntityManager();
	}*/
}
